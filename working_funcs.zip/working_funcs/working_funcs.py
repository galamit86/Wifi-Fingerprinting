## A function to rotate x, y coordinates by a specified angle
## Takes x, y and rotation angle in degrees, and returns converted x_rot, y_rot coordinateds

def rotate_both (x, y, deg_angle):
    from numpy import sin, cos, pi
    x_rot = x*cos(deg_angle*pi/180) + y*sin(deg_angle*pi/180)
    y_rot = -x*sin(deg_angle*pi/180) + y*cos(deg_angle*pi/180)
    return x_rot, y_rot

## A function to rotate x only coordinates by specified angle
## Takes x, y and rotation angle in degrees, and returns converted x_rot coordinateds
def rotate_x (x, y, deg_angle):
    from numpy import sin, cos, pi
    x_rot = x*cos(deg_angle*pi/180) + y*sin(deg_angle*pi/180)
    y_rot = -x*sin(deg_angle*pi/180) + y*cos(deg_angle*pi/180)
    return x_rot

## A function taking a Series, and returning a new series where all values are a percent of the maximum value in the series
## Designed for negative values, and therefore returns 1/value
def to_perc_neg (ser, to_zero):
    from pandas import Series
    ls = []
    maximum = max(ser)
    for i in range(len(ser)):
        if ser[i] == to_zero:
            ls.append(0)
        else:
            ls.append(1/(ser[i]/maximum))
    new_ser = Series(ls, index = ser.index)
    return new_ser

## A function taking a Series, and returning a new series where all values are a percent of the maximum value in the series
def to_perc (ser, to_zero):
    from pandas import Series
    ls = []
    maximum = max(ser)
    for i in range(len(ser)):
        if ser[i] == to_zero:
            ls.append(0)
        else:
            ls.append(ser[i]/maximum)
    new_ser = Series(ls, index = ser.index)
    return new_ser